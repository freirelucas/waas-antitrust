"""Varredura de Sobol e análise de sensibilidade global."""
from waas_antitrust.sobol.problema import PROBLEMA_SOBOL_8D
from waas_antitrust.sobol.execucao import executar_para_sobol, executar_varredura

__all__ = ["PROBLEMA_SOBOL_8D", "executar_para_sobol", "executar_varredura"]
